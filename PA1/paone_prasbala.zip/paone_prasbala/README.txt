The program decisiontree.py was coded in python 2.7

To run the program use the below command

python decisiontree.py train_file_name depth test_file_name
